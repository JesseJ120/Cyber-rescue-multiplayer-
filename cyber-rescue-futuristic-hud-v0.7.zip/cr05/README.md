# Cyber Rescue Multiplayer

Online multiplayer browser game prototype for a school competition.

## Deploy on Render
1. Push this folder to a GitHub repository.
2. In Render, choose **New → Web Service** and connect the repository.
3. Render detects the Node.js app. Build: `npm install`; Start: `npm start`.
4. Deploy and open the generated `onrender.com` URL.
5. Share that URL with classmates. Players enter the same room code to play together.

The server uses Socket.IO over the same HTTP service, so no separate WebSocket server is required.


## v0.7 — Futuristic HUD
This version uses a central cyber-city visual layer inspired by the Cyber Rescue concept art while keeping the HUD, multiplayer players, server, enemies, mission controls, network map, team comms, and live mission state interactive. The city artwork is embedded as a local asset so the game does not depend on an external image URL.
